package GenericScale;

public class Main {
}
